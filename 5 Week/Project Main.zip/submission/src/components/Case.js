import React from 'react';
import "../css/Case.css"
import Wheel from './Wheel.js'
import Display from './Display.js'

// This component is the outer case of iPod it does nothing special just renders display and wheel component
class Case extends React.Component {
    render() {
        const {active,updateActiveMenu, currentMenu, changeMenuBackward,changeMenuForward, menuItems, musicItems,wallpaper, wallpaperItems} = this.props;
        return (
            <div className="case-container">
                <div className="case">
                    <Display 
                        active={active}
                        musicItems={musicItems}
                        menuItems={menuItems}
                        currentMenu={currentMenu}
                        wallpaper={wallpaper}
                        wallpaperItems={wallpaperItems}
                    />

                    <Wheel 
                        active={active}
                        menuItems={menuItems}
                        currentMenu={currentMenu}
                        changeMenuForward={changeMenuForward}
                        changeMenuBackward={changeMenuBackward}
                        updateActiveMenu={updateActiveMenu}
                    />
                </div>
            </div>
        )
    }
}

export default Case;