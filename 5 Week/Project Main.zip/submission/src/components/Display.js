import React from 'react';
import Menu from '../components/Menu';
import Music from '../components/Music';
import "../css/Display.css"
import LockScreen from './LockScreen';

// On the basis of what the current menu is this item will render only that component
// Also this displays the navigation bar
// Key for displaying menu
// {-2: lock screen, -1 : main menu, 0 : now playing, 1: music menu, 2,5,6 : dummy menu, 3: setings menu,4:songs menu, 7:music playing, 8 :themes menu, 9:wheel color menu, 10:wallpaper menu}

class Display extends React.Component {
    render() {
        const { active, currentMenu, menuItems, musicItems,wallpaper,wallpaperItems} = this.props;
        
        return (
            <div style={{backgroundImage:`url(${wallpaperItems[wallpaper]})`}} className="display">
               
                {currentMenu===-2&&<LockScreen/>}
                {currentMenu === -1 && <Menu menuItems={menuItems} active={active} />}
                {currentMenu === 1 && <Music musicItems={musicItems} active={active} />}
                {currentMenu === 2 && <div className="blank-div"><h1 className="empty-text">Games</h1></div>}
                {currentMenu === 5 && <div className="blank-div"><h1 className="empty-text">Artists</h1></div>}
                {currentMenu === 6 && <div className="blank-div"><h1 className="empty-text">Albums</h1></div>}
            </div>
        )
    }
}


export default Display;