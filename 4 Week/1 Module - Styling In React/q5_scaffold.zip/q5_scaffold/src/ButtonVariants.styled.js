import styled from "styled-components";

// Complete the below given ButtonView style Component

export const ButtonView = styled.button`
`;
